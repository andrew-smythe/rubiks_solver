import java.util.ArrayList;

public class TreeSearchAI {
	
	private ArrayList<Node> expand(Node n, Problem p) {
		ArrayList<Node> successors = new ArrayList<Node>();
		
		for (Pair<Action, State> pair : p.SuccessorFn(n.getState())) {
			int pathCost = n.getCost() + p.pathCost(n.getState(), pair.getL(), pair.getR()) + p.heuristicCost(n.getState());
			Node s = new Node(n, pair.getL(), pair.getR(), n.getDepth()+1, pathCost);
			successors.add(s);			
		}
		return successors;
	}
	
	public Node TreeSearch(Problem problem, Fringe fringe) {
		// Create a node from the start state
		fringe.insert(new Node(problem.getStartState()));
		
		// Continue searching while the fringe is empty
		while (!fringe.isEmpty()) {
			Node n = fringe.getFirstNode();
			if (problem.goalTest(n.getState()))
				return n;
			else
				fringe.insertAll(expand(n, problem));
		}
		return null;
	}
	
	public static void main(String[] argv) {
		AStarProblem problem = new AStarProblem();
		AStarFringe fringe = new AStarFringe();
		TreeSearchAI search = new TreeSearchAI();
		
		Node finalNode = search.TreeSearch(problem, fringe);
		Node n = finalNode;
		while (n != null) {
			System.out.println(n.getState().getStateContents());
			n = n.getParent();
		}
	}
}
